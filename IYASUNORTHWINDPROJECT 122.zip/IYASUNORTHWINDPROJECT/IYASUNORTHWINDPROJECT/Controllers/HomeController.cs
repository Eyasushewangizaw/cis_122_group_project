﻿using IYASUNORTHWINDPROJECT.Models;
using Microsoft.AspNetCore.Mvc;

namespace IYASUNORTHWINDPROJECT.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            getway aGateway = new getway();



            List<categories> aListOfCategories = aGateway.GetCategory("C:\\Users\\15073\\OneDrive\\Desktop\\farew\\Categories (1).csv");
            ViewBag.ListOfCategories = aListOfCategories;


            List<employees> aListOfEmployees = aGateway.GetEmployee("C:\\Users\\15073\\OneDrive\\Desktop\\farew\\Employees (1).csv");
            ViewBag.ListOfEmployees = aListOfEmployees;


            List<OrderDetails> aListOfOrderDetails = aGateway.GetOrderDetail("C:\\Users\\15073\\Downloads\\OrderDetails.csv");
            ViewBag.ListOfOrderDetails = aListOfOrderDetails;


            List<Products> aListOfProducts = aGateway.GetProduct("C:\\Users\\15073\\OneDrive\\Desktop\\farew\\Products (1).csv");
            ViewBag.ListOfProducts = aListOfProducts;


            List<Shippers> aListOfShippers = aGateway.GetShipper("C:\\Users\\15073\\OneDrive\\Desktop\\farew\\Shippers (1).csv");
            ViewBag.ListOfShippers = aListOfShippers;


            List<Suppliers> aListOfSuppliers = aGateway.GetSupplier("C:\\Users\\15073\\OneDrive\\Desktop\\farew\\Suppliers (1).csv");
            ViewBag.ListOfSuppliers = aListOfSuppliers;
            return View();
        }
    }
}
